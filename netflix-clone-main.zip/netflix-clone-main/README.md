# Netflix-clone
# clone : https://netflix-clone-e2254.web.app/ 
# First web app deployment project for getting better understanding regarding Reactjs.
# 
# Stepwise Breakdown👇🏻
# 1) Demo app creation
# 2) Got TMDB API key and used in POSTMAN 
# 3) Created a React APP
# 4) Setup firebase hosting
# 5) Got all MOVIES
# 6) Built the Rows
# 7) Built the Banner
# 8) Built Nav Bar 
# 9) Added Trailer Popup Feature (works for very few movies btw)
# 10) Deployment at last to firebase
